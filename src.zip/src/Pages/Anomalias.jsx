import Header from '../components/Header';
import './Anomalias.css';

function PPg() {
  return (
    <>
    <Header />
    
    </>
  );
}

export default PPg;
