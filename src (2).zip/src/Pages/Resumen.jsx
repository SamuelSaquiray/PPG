function Resumen(){
    return (
        <div>
            <h1>Resumen</h1>
            <p>En esta sección se mostrará un resumen de la información más relevante del usuario.</p>
        </div>
    );
}
export default Resumen; 